// Función para generar flores flotantes
function createFlower() {
    const flower = document.createElement('div');
    flower.classList.add('flower');

    // Coloca la flor en una posición aleatoria horizontalmente dentro de la ventana
    flower.style.left = `${Math.random() * window.innerWidth}px`; // Posición aleatoria en el eje X

    // Añade la flor al contenedor de flores
    document.getElementById('flowerContainer').appendChild(flower);

    // Elimina la flor después de que haya caído (limpiar la memoria)
    setTimeout(() => {
        flower.remove();
    }, 5000); // Después de 5 segundos
}

// Genera flores cada 100ms
setInterval(createFlower, 100);

